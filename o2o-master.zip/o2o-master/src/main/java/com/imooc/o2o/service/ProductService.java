package com.imooc.o2o.service;

import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.imooc.o2o.dto.ImageHolder;
import com.imooc.o2o.dto.ProductExecution;
import com.imooc.o2o.entity.Product;
import com.imooc.o2o.exceptions.ProductCategoryOperationException;

public interface ProductService {
	/**
	 * ��ѯ��Ʒ�б�����ҳ
	 * @param productCondition
	 * @param pageIndex
	 * @param pageSize
	 * @return
	 */
    ProductExecution getProductList(Product productCondition, int pageIndex, int pageSize);
    /**
     * ͨ����Ʒid��ѯΨһ����Ʒ��Ϣ
     * @param productId
     * @return
     */
	Product getProductById(long productId);
    /**
     * ������Ʒ��Ϣ�Լ�ͼƬ����
     * @param product
     * @param thumbnail
     * @param productImgs
     * @return
     * @throws RuntimeException
     */
	ProductExecution addProduct(Product product, ImageHolder thumbnail, 
			List<ImageHolder> productImgList)
			throws ProductCategoryOperationException;
    /**
     * 
     * @param product
     * @param thumbnail
     * @param productImgs
     * @return
     * @throws RuntimeException
     */
	ProductExecution modifyProduct(Product product, ImageHolder thumbnail,
			List<ImageHolder> productImgHolderList) throws ProductCategoryOperationException;
}
