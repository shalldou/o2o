package com.imooc.o2o.dto;

import java.util.List;

import com.imooc.o2o.entity.HeadLine;
import com.imooc.o2o.enums.HeadLineStateEnum;


public class HeadLineExecution {
	// 缁撴灉鐘舵��
	private int state;

	// 鐘舵�佹爣璇�
	private String stateInfo;

	// 搴楅摵鏁伴噺
	private int count;

	// 鎿嶄綔鐨刟ward锛堝鍒犳敼鍟嗗搧鐨勬椂鍊欑敤锛�
	private HeadLine headLine;

	// 鑾峰彇鐨刟ward鍒楄〃(鏌ヨ鍟嗗搧鍒楄〃鐨勬椂鍊欑敤)
	private List<HeadLine> headLineList;

	public HeadLineExecution() {
	}

	// 澶辫触鐨勬瀯閫犲櫒
	public HeadLineExecution(HeadLineStateEnum stateEnum) {
		this.state = stateEnum.getState();
		this.stateInfo = stateEnum.getStateInfo();
	}

	// 鎴愬姛鐨勬瀯閫犲櫒
	public HeadLineExecution(HeadLineStateEnum stateEnum, HeadLine headLine) {
		this.state = stateEnum.getState();
		this.stateInfo = stateEnum.getStateInfo();
		this.headLine = headLine;
	}

	// 鎴愬姛鐨勬瀯閫犲櫒
	public HeadLineExecution(HeadLineStateEnum stateEnum, List<HeadLine> headLineList) {
		this.state = stateEnum.getState();
		this.stateInfo = stateEnum.getStateInfo();
		this.headLineList = headLineList;
	}

	public int getState() {
		return state;
	}

	public void setState(int state) {
		this.state = state;
	}

	public String getStateInfo() {
		return stateInfo;
	}

	public void setStateInfo(String stateInfo) {
		this.stateInfo = stateInfo;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public HeadLine getHeadLine() {
		return headLine;
	}

	public void setHeadLine(HeadLine headLine) {
		this.headLine = headLine;
	}

	public List<HeadLine> getHeadLineList() {
		return headLineList;
	}

	public void setHeadLineList(List<HeadLine> headLineList) {
		this.headLineList = headLineList;
	}

}
