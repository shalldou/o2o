package com.imooc.o2o.util;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Random;

import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.imooc.o2o.dto.ImageHolder;

import net.coobird.thumbnailator.Thumbnails;
import net.coobird.thumbnailator.geometry.Positions;

public class ImageUtil {
	private static Logger logger = LoggerFactory.getLogger(ImageUtil.class);
	private static final SimpleDateFormat SIMPLE_DATE_FORMAT =
			new SimpleDateFormat("yyyyMMddHHmmss");
	private static final Random R= new Random();
	
	private static String basePath = Thread.currentThread().getContextClassLoader()
			.getResource("").getPath();
	/**
	 * ��CommonsMultipartFileת��file
	 * @param cFile
	 * @return
	 */
	public static File transferCommonsMutipartFileToFile(
			CommonsMultipartFile cFile){
		File newFile = new File(cFile.getOriginalFilename());
		try {
			cFile.transferTo(newFile);
		} catch (IllegalStateException e) {
			logger.error(e.toString());
			e.printStackTrace();
		} catch (IOException e) {
			logger.error(e.toString());
			e.printStackTrace();
		}
		return newFile;
	}
	
	/**
	 * ��������ͼ�������������ɵ�ͼƬ�����·��
	 * @param thumbnail
	 * @param targetAddr
	 * @return
	 */
	
	public static String generateThumbnail(ImageHolder thumbnail,
			String targetAddr){
		String realFileName = getRandomFileName();
		String extension = getFileExtension(thumbnail.getImageName());
		
		makeDirPath(targetAddr);
		String relativeAddr = targetAddr+realFileName+extension;
		logger.debug("current relativeAddr is"+relativeAddr);
		File dest = new File(PathUtil.getImgBasePath()+relativeAddr);
		logger.debug("current complete addr is"+relativeAddr+PathUtil.getImgBasePath());
		try{
			Thumbnails.of(thumbnail.getImage()).size(200, 200)
			.watermark(Positions.BOTTOM_RIGHT,
					ImageIO.read(new File(basePath+"/watermark.jpg")),0.25f)
			.outputQuality(0.8f).toFile(dest);
			
		}catch (IOException e) {
			logger.error(e.toString());
			e.printStackTrace();
		}
		return relativeAddr;	
	}
	
	/**
	 * ����Ŀ��·�����漰��Ŀ¼������home/work/xiangze/xxx
	 * ��ôhome,work,xiangze,�������ļ��ж����Զ�����
	 * @param targetAddr
	 */
	private static void makeDirPath(String targetAddr) {
		String realFilePath = PathUtil.getImgBasePath()+targetAddr;
		File dirPath = new File(realFilePath);
		if(!dirPath.exists()){
			dirPath.mkdirs();
		}
		
	}


	/**
	 *��ȡ�����ļ�������չ�� 
	 * @param thumbnail
	 * @return
	 */
	private static String getFileExtension(String fileName) {
	
		
		return fileName.substring(fileName.lastIndexOf("."));
	}



	/**
	 * ��������ļ�������ǰ������Сʱ����+��λ�����
	 * @return
	 */
	public  static String getRandomFileName() {
		
		int rannum = R.nextInt(89999)+10000;
		String nowTimeStr = SIMPLE_DATE_FORMAT.format(new Date());
		
		return nowTimeStr+rannum;
	}




	public static void main(String[] args) throws IOException {
		 
		
		Thumbnails.of(new File("C:/Users/Administrator/Pictures/xiao.jpg"))
		.size(200, 200).watermark(Positions.BOTTOM_RIGHT,
				ImageIO.read(new File(basePath+"/watermark.jpg")),0.25f)
		.outputQuality(0.8f).toFile("C:/Users/Administrator/Pictures/xiaoNew.jpg");
	}
	
	/**
	 * storePath���ļ���·������Ŀ¼��·��
	 * ������ļ�·������ɾ�����ļ�
	 * �����Ŀ¼����ɾ����Ŀ¼�µ����е��ļ�
	 * @param storePath
	 */
	public  static void deleteFileOrPath(String storePath){
		File fileOrPath = new File(PathUtil.getImgBasePath()+storePath);
		if(fileOrPath.exists()){
			if(fileOrPath.isDirectory()){
				File files[] =fileOrPath.listFiles();
				for (int i = 0; i < files.length; i++) {
					files[i].delete();
				}
			}	
			fileOrPath.delete();
		}
		
	}

	public static String generateNormalImg(ImageHolder thumbnail, String targetAddr) {
		
		String realFileName = getRandomFileName();
		String extension = getFileExtension(thumbnail.getImageName());
		
		makeDirPath(targetAddr);
		String relativeAddr = targetAddr+realFileName+extension;
		logger.debug("current relativeAddr is"+relativeAddr);
		File dest = new File(PathUtil.getImgBasePath()+relativeAddr);
		logger.debug("current complete addr is"+relativeAddr+PathUtil.getImgBasePath());
		try{
			Thumbnails.of(thumbnail.getImage()).size(337, 640)
			.watermark(Positions.BOTTOM_RIGHT,
					ImageIO.read(new File(basePath+"/watermark.jpg")),0.25f)
			.outputQuality(0.9f).toFile(dest);
			
		}catch (IOException e) {
			logger.error(e.toString());
			e.printStackTrace();
		}
		return relativeAddr;
	}
		
	
}
