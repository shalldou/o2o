package com.imooc.o2o.service;

import java.io.IOException;
import java.util.List;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.imooc.o2o.dto.ShopCategoryExecution;
import com.imooc.o2o.entity.ShopCategory;


public interface ShopCategoryService {

	/**
	 * ���ݲ�ѯ������ȡshopcategory�б�
	 * @param shopCategoryCondition
	 * @return
	 */
	List<ShopCategory> getShopCategoryList(ShopCategory shopCategoryCondition);
	
	
	
//	List<ShopCategory> getFirstLevelShopCategoryList() throws IOException;
//
//	
//	
//
//	/**
//	 * 
//	 * @return
//	 * @throws IOException
//	 */
//	List<ShopCategory> getAllSecondLevelShopCategory() throws IOException;
//
//	/**
//	 * 
//	 * @param shopCategory
//	 * @return
//	 */
//	ShopCategory getShopCategoryById(Long shopCategoryId);
//
//	/**
//	 * 
//	 * @param shopCategory
//	 * @param thumbnail
//	 * @return
//	 */
//	ShopCategoryExecution addShopCategory(ShopCategory shopCategory,
//			CommonsMultipartFile thumbnail);
//
//	/**
//	 * 
//	 * @param shopCategory
//	 * @param thumbnail
//	 * @param thumbnailChange
//	 * @return
//	 */
//	ShopCategoryExecution modifyShopCategory(ShopCategory shopCategory,
//			CommonsMultipartFile thumbnail, boolean thumbnailChange);
//
//	/**
//	 * 
//	 * @param shopCategoryId
//	 * @return
//	 */
//	ShopCategoryExecution removeShopCategory(long shopCategoryId);
//
//	/**
//	 * 
//	 * @param shopCategoryIdList
//	 * @return
//	 */
//	ShopCategoryExecution removeShopCategoryList(List<Long> shopCategoryIdList);

}
