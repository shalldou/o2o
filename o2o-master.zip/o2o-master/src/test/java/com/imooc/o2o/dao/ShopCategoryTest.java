package com.imooc.o2o.dao;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.imooc.o2o.entity.Area;
import com.imooc.o2o.entity.ShopCategory;

public class ShopCategoryTest extends BaseTest{

	@Autowired
	private ShopCategoryDao shopCategoryDao;

	
	@Test
	public void test(){
		List<ShopCategory> shopCategorieList 
		= shopCategoryDao.queryShopCategory(null);
		 
		
		System.out.println(shopCategorieList.size());
		
		
	}
}
