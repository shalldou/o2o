package com.imooc.o2o.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

import org.springframework.beans.factory.annotation.Autowired;

import com.imooc.o2o.entity.ProductImg;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProductImgDaoTest extends BaseTest{

	@Autowired
	private ProductImgDao productImgDao;
	
	@Test
	public void testABatch()throws Exception{
		ProductImg productImg1 =new ProductImg();
		productImg1.setImgAddr("ͼƬ1");
		productImg1.setImgDesc("����ͼƬ1");
		productImg1.setPriority(1);
		productImg1.setCreateTime(new Date());
		productImg1.setProductId(1l);
		ProductImg productImg2 =new ProductImg();
		productImg2.setImgAddr("ͼƬ2");
		productImg2.setImgDesc("����ͼƬ2");
		productImg2.setPriority(1);
		productImg2.setCreateTime(new Date());
		productImg2.setProductId(1l);
		List<ProductImg> pList = new ArrayList<ProductImg>();
		pList.add(productImg1);
		pList.add(productImg2);
		int effectnum = productImgDao.batchInsertProductImg(pList);
		System.out.println(effectnum);
	
		
	}
	
	@Test
	public void testBqueryProductImgList(){
		List<ProductImg> productImgs = productImgDao.queryProductImgList(1);
		System.out.println(productImgs.size());
	}
	
	@Test
	public void testCDelete(){
		long productId=1;
		int effectedNum = productImgDao.deleteProductImgByProductId(productId);
		System.out.println(effectedNum);
	}
	
	
	
	
	
	
	
	
	
	
}
