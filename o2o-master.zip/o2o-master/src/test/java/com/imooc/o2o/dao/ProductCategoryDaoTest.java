package com.imooc.o2o.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.propertyeditors.PathEditor;

import com.imooc.o2o.entity.ProductCategory;
import com.imooc.o2o.entity.Shop;

public class ProductCategoryDaoTest extends BaseTest{

	
	@Autowired
	private ProductCategoryDao productCategoryDao;
	
	@Test
	public void testQueryByShopId()throws Exception{
		long shopId=1;
		List<ProductCategory> productCategories= productCategoryDao.queryProductCategoryList(shopId);
		System.out.println("�õ��̵��Զ��������Ϊ"+productCategories.size());
	}
	
	@Test
	public  void testBatchInsert(){
		ProductCategory productCategory = new ProductCategory();
		productCategory.setProductCategoryName("��Ʒ���1");
		productCategory.setPriority(1);
		productCategory.setCreateTime(new Date());
		productCategory.setShopId(1l);
		ProductCategory productCategory2 = new ProductCategory();
		productCategory2.setProductCategoryName("��Ʒ���2");
		productCategory2.setPriority(2);
		productCategory2.setCreateTime(new Date());
		productCategory2.setShopId(1l);
		List<ProductCategory> productCategoryList=new ArrayList<ProductCategory>();
		productCategoryList.add(productCategory);
		productCategoryList.add(productCategory2);
		int effect=productCategoryDao.batchInsertProductCategory(productCategoryList);
		System.out.println(effect);
		
	}
	@Test
	public void testDelete(){
		ProductCategory productCategory = new ProductCategory();
		Shop shop = new Shop();
		long productCategoryId=4l;
		long shopId = 1l;
		int effectnum = productCategoryDao.deleteProductCategory(productCategoryId, shopId);
		System.out.println(effectnum);
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
