package com.imooc.o2o.dao;


import java.util.Date;
import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.imooc.o2o.entity.Area;
import com.imooc.o2o.entity.PersonInfo;
import com.imooc.o2o.entity.Shop;
import com.imooc.o2o.entity.ShopCategory;

public class ShopDaoTest extends BaseTest{

	@Autowired
	private ShopDao shopDao;
	
	@Test
	public  void testQueryByShopId() {
		long shopId =1;
		Shop shop = shopDao.queryByShopId(shopId);
		System.out.println(shop.getArea().getAreaName()+",areaname");
		System.out.println(shop.getArea().getAreaId()+",araeId");

	}
	
//	@Test
//	public void testInsertShop(){
//		Shop shop = new Shop();
//		PersonInfo owner = new PersonInfo();
//		ShopCategory shopCategory = new ShopCategory();
//		Area area = new Area();
//		owner.setUserId(1l);
//		area.setAreaId(2);
//		shopCategory.setShopCategoryId(1l);
//		shop.setOwner(owner);
//		shop.setArea(area);
//		shop.setShopCategory(shopCategory);
//		shop.setShopName("С��");
//		shop.setShopDesc("������");
//		shop.setShopAddr("te����");
//		shop.setPhone("tt");
//		shop.setCreateTime(new Date());
//		shop.setEnableStatus(1);
//		shop.setAdvice("�����");
//		shop.setPriority(1);
//		int effectNum = shopDao.insertShop(shop);
//		System.out.println(effectNum);
//		
//	}
	
	
	@Test
	public void updateShop(){
		Shop shop = new Shop();
		shop.setShopId(3l);
		shop.setShopDesc("��������");
		shop.setShopAddr("���Ե�ַ");
		
		int effectNum = shopDao.updateShop(shop);
		System.out.println(effectNum);
		
	}
	
	
	@Test
	public void testQueryAndCount(){
		Shop shopCondition = new Shop();
		PersonInfo owner = new PersonInfo();
		owner.setUserId(1l);
		shopCondition.setOwner(owner);
		List<Shop> sholist=shopDao.queryShopList(shopCondition, 0, 5);
		int count = shopDao.queryShopCount(shopCondition);
		System.out.println("�����б��Ĵ�С"+sholist.size());
		System.out.println("��������"+count);
	}
	
	
	
	
	
	
	
	
	
	
	
	
}
