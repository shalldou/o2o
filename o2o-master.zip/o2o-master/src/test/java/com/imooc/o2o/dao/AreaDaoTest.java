package com.imooc.o2o.dao;

import java.util.List;

import javax.annotation.Resource;


import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.imooc.o2o.entity.Area;
import com.imooc.o2o.service.AreaService;

public class AreaDaoTest extends BaseTest{


	
	@Autowired
	private AreaDao areaDao;
	@Resource
	private AreaService areaService;
	
	@Test
	public void testQueryArea(){
		
		List<Area> areas = areaDao.queryArea();
		
		System.out.println(areas);
	}
	
	@Test
	public void testArea(){
		List<Area> areas = areaService.getAreaList();
		System.out.println(areas);
	}
	
}
