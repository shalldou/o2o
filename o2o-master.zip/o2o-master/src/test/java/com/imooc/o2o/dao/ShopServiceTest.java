package com.imooc.o2o.dao;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.Date;

import javax.annotation.Resource;

import org.eclipse.jdt.internal.compiler.batch.Main;
import org.junit.Test;
import org.omg.CORBA.PUBLIC_MEMBER;
import org.springframework.beans.factory.annotation.Autowired;

import com.imooc.o2o.dto.ShopExecution;
import com.imooc.o2o.entity.Area;
import com.imooc.o2o.entity.PersonInfo;
import com.imooc.o2o.entity.Shop;
import com.imooc.o2o.entity.ShopCategory;
import com.imooc.o2o.enums.ShopStateEnum;
import com.imooc.o2o.exceptions.ShopOperationException;
import com.imooc.o2o.service.ShopService;

public class ShopServiceTest extends BaseTest{

	@Autowired
	private ShopService shopService;
//	
//	@Test
//	public void testModifyShop()throws ShopOperationException,FileNotFoundException{
//		Shop shop = new Shop();
//		shop.setShopId(1l);
//		shop.setShopName("�޸ĺ��");
//		File file = new  File("D:/Pictures/xiao.jpg");
//		InputStream is= new FileInputStream(file);
//		
//		ShopExecution shopExecution=shopService.modifiShop(shop, is, "xiao.jpg");
//	    System.out.println("�µ�ͼƬ��ַ"+shopExecution.getShop().getShopImg());
//	}
//	
//	@Test
//	public void testAddTest() throws FileNotFoundException{
//		Shop shop = new Shop();
//		
//		PersonInfo owner = new PersonInfo();
//		ShopCategory shopCategory = new ShopCategory();
//		Area area = new Area();
//		owner.setUserId(1l);
//		area.setAreaId(2);
//		System.out.println(owner+"owner");
//		shopCategory.setShopCategoryId(1l);
//		shop.setOwner(owner);
//		shop.setArea(area);
//		shop.setShopCategory(shopCategory);
//		shop.setShopName("����u");
//		shop.setShopDesc("vt1");
//		shop.setShopAddr("tesvv");
//		shop.setPhone("test3432");
//		shop.setCreateTime(new Date());
//		shop.setEnableStatus(ShopStateEnum.CHECK.getState());
//		shop.setAdvice("�����");
//		
//		File shopImg=new File("D:\\Pictures\\xiao.jpg");
//		
//		InputStream is=new FileInputStream(shopImg);
//		ShopExecution se=shopService.addShop(shop,is, shopImg.getName());
//		System.out.println(ShopStateEnum.CHECK.getState()+se.getState());
//		
//	}
//	
//	@Test
//	public void testGetShopList(){
//		Shop shopCondition = new Shop();
//		ShopCategory sc= new ShopCategory();
//		sc.setShopCategoryId(3l);
//		shopCondition.setShopCategory(sc);
//		ShopExecution se= shopService.getShopList(shopCondition, 1, 2);
//		
//		System.out.println("�����б���"+se.getShopList().size());
//		System.out.println("��������"+se.getCount());		
//	}
//	
	
	
}
