package com.imooc.o2o.dao;



import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;
import org.junit.validator.PublicClassValidator;
import org.springframework.beans.factory.annotation.Autowired;

import com.imooc.o2o.entity.Product;
import com.imooc.o2o.entity.ProductCategory;
import com.imooc.o2o.entity.Shop;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class ProductDaoTest extends BaseTest{

	@Autowired
	private ProductDao productDao;
	
	@Test
	public void testAInsert()throws Exception{
		Shop shop1= new Shop();
		shop1.setShopId(1l);
		ProductCategory pc1= new ProductCategory();
		pc1.setProductCategoryId(1l);
		//��ʼ��������Ʒʵ�������ӽ�shopIdΪ1�ĵ����ͬʱ��Ʒ���ҲΪ1
		Product product1 = new Product();
		product1.setProductName("����1");
		product1.setProductDesc("ceshidesc1");
		product1.setImgAddr("test1");
		product1.setPriority(1);
		product1.setEnableStatus(1);
		product1.setCreateTime(new Date());
		product1.setLastEditTime(new Date());
		product1.setShop(shop1);
		product1.setProductCategory(pc1);
		
		Product product2 = new Product();
		product2.setProductName("����2");
		product2.setProductDesc("ceshidesc2");
		product2.setImgAddr("test2");
		product2.setPriority(2);
		product2.setEnableStatus(2);
		product2.setCreateTime(new Date());
		product2.setLastEditTime(new Date());
		product2.setShop(shop1);
		product2.setProductCategory(pc1);
		
		
		int effctNum = productDao.insertProduct(product1);
		System.out.println(effctNum);
		
	}
	
}
